`ifndef xlConvPkgIncluded
`include "conv_pkg.v"
`endif

`timescale 1 ns / 10 ps
// Generated from Simulink block DMA_throttle_sysgen/AXIS_DMA_throttle_w_CDC_struct
module axis_dma_throttle_w_cdc_struct (
  input [32-1:0] data_in_a,
  input [32-1:0] data_in_b,
  input [32-1:0] decim_in,
  input [1-1:0] m_axis_dma_tready,
  input [32-1:0] frames_no_in,
  input [1-1:0] trigger_in,
  input clk_1,
  input ce_1,
  output [32-1:0] m_axis_dma_tdata,
  output [1-1:0] m_axis_dma_tvalid,
  output [1-1:0] m_axis_dma_tlast
);
  wire [32-1:0] data_in_b_net;
  wire [1-1:0] logical3_y_net;
  wire ce_net;
  wire [32-1:0] mux_y_net;
  wire [1-1:0] m_axis_dma_tready_net;
  wire [1-1:0] mux2_y_net;
  wire [32-1:0] data_in_a_net;
  wire [32-1:0] decim_in_net;
  wire [32-1:0] frames_no_in_net;
  wire [1-1:0] trigger_in_net;
  wire clk_net;
  wire [1-1:0] relational_op_net;
  wire [8-1:0] decim_counter_op_net;
  wire [1-1:0] logical2_y_net;
  wire [1-1:0] counter1_op_net;
  wire [1-1:0] delay3_q_net;
  wire [1-1:0] logical5_y_net;
  wire [32-1:0] register_q_net;
  wire [32-1:0] register1_q_net;
  wire [1-1:0] logical_y_net;
  wire [1-1:0] delay2_q_net;
  wire [32-1:0] register3_q_net;
  wire [1-1:0] delay4_q_net;
  wire [1-1:0] register6_q_net;
  wire [1-1:0] logical1_y_net;
  wire [1-1:0] register5_q_net;
  wire [32-1:0] frame_counter_op_net;
  wire [1-1:0] last_flag_op_net;
  wire [1-1:0] constant_op_net;
  wire [32-1:0] register2_q_net;
  wire [1-1:0] register4_q_net;
  wire [1-1:0] logical4_y_net;
  wire [1-1:0] inverter_op_net;
  assign m_axis_dma_tdata = mux_y_net;
  assign m_axis_dma_tvalid = logical3_y_net;
  assign data_in_a_net = data_in_a;
  assign data_in_b_net = data_in_b;
  assign decim_in_net = decim_in;
  assign m_axis_dma_tready_net = m_axis_dma_tready;
  assign frames_no_in_net = frames_no_in;
  assign m_axis_dma_tlast = mux2_y_net;
  assign trigger_in_net = trigger_in;
  assign clk_net = clk_1;
  assign ce_net = ce_1;
  axis_dma_throttle_w_cdc_xlcounter_free #(
    .core_name0("axis_dma_throttle_w_cdc_c_counter_binary_v12_0_i0"),
    .op_arith(`xlUnsigned),
    .op_width(8)
  )
  decim_counter (
    .clr(1'b0),
    .rst(relational_op_net),
    .en(logical5_y_net),
    .clk(clk_net),
    .ce(ce_net),
    .op(decim_counter_op_net)
  );
  sysgen_counter_bbbc0adeb2 counter1 (
    .clr(1'b0),
    .en(logical2_y_net),
    .clk(clk_net),
    .ce(ce_net),
    .op(counter1_op_net)
  );
  axis_dma_throttle_w_cdc_xldelay #(
    .latency(2),
    .reg_retiming(0),
    .reset(0),
    .width(1)
  )
  delay2 (
    .en(1'b1),
    .rst(1'b0),
    .d(logical_y_net),
    .clk(clk_net),
    .ce(ce_net),
    .q(delay2_q_net)
  );
  axis_dma_throttle_w_cdc_xldelay #(
    .latency(1),
    .reg_retiming(0),
    .reset(0),
    .width(1)
  )
  delay3 (
    .en(1'b1),
    .rst(1'b0),
    .d(relational_op_net),
    .clk(clk_net),
    .ce(ce_net),
    .q(delay3_q_net)
  );
  sysgen_logical_26b62a7620 logical (
    .clk(1'b0),
    .ce(1'b0),
    .clr(1'b0),
    .d0(relational_op_net),
    .d1(delay3_q_net),
    .y(logical_y_net)
  );
  sysgen_mux_4504b33b01 mux (
    .clr(1'b0),
    .sel(counter1_op_net),
    .d0(register_q_net),
    .d1(register1_q_net),
    .clk(clk_net),
    .ce(ce_net),
    .y(mux_y_net)
  );
  axis_dma_throttle_w_cdc_xlregister #(
    .d_width(32),
    .init_value(32'b00000000000000000000000000000000)
  )
  register (
    .rst(1'b0),
    .d(data_in_a_net),
    .en(relational_op_net),
    .clk(clk_net),
    .ce(ce_net),
    .q(register_q_net)
  );
  axis_dma_throttle_w_cdc_xlregister #(
    .d_width(32),
    .init_value(32'b00000000000000000000000000000000)
  )
  register1 (
    .rst(1'b0),
    .d(data_in_b_net),
    .en(relational_op_net),
    .clk(clk_net),
    .ce(ce_net),
    .q(register1_q_net)
  );
  sysgen_relational_e09863b361 relational (
    .clr(1'b0),
    .a(decim_counter_op_net),
    .b(register3_q_net),
    .clk(clk_net),
    .ce(ce_net),
    .op(relational_op_net)
  );
  axis_dma_throttle_w_cdc_xlregister #(
    .d_width(32),
    .init_value(32'b00000000000000000000000000000000)
  )
  register3 (
    .en(1'b1),
    .rst(1'b0),
    .d(decim_in_net),
    .clk(clk_net),
    .ce(ce_net),
    .q(register3_q_net)
  );
  sysgen_logical_bb947eda3b logical1 (
    .clk(1'b0),
    .ce(1'b0),
    .clr(1'b0),
    .d0(relational_op_net),
    .d1(register5_q_net),
    .d2(register6_q_net),
    .y(logical1_y_net)
  );
  axis_dma_throttle_w_cdc_xlregister #(
    .d_width(1),
    .init_value(1'b0)
  )
  register6 (
    .en(1'b1),
    .rst(1'b0),
    .d(m_axis_dma_tready_net),
    .clk(clk_net),
    .ce(ce_net),
    .q(register6_q_net)
  );
  sysgen_relational_e14fbccb64 last_flag (
    .clr(1'b0),
    .a(frame_counter_op_net),
    .b(register2_q_net),
    .clk(clk_net),
    .ce(ce_net),
    .op(last_flag_op_net)
  );
  sysgen_logical_9fc906f096 logical5 (
    .clk(1'b0),
    .ce(1'b0),
    .clr(1'b0),
    .d0(register5_q_net),
    .d1(register6_q_net),
    .y(logical5_y_net)
  );
  axis_dma_throttle_w_cdc_xlcounter_free #(
    .core_name0("axis_dma_throttle_w_cdc_c_counter_binary_v12_0_i1"),
    .op_arith(`xlUnsigned),
    .op_width(32)
  )
  frame_counter (
    .clr(1'b0),
    .rst(last_flag_op_net),
    .en(logical1_y_net),
    .clk(clk_net),
    .ce(ce_net),
    .op(frame_counter_op_net)
  );
  sysgen_mux_1c06908f38 mux2 (
    .clr(1'b0),
    .sel(register5_q_net),
    .d0(constant_op_net),
    .d1(last_flag_op_net),
    .clk(clk_net),
    .ce(ce_net),
    .y(mux2_y_net)
  );
  sysgen_logical_9fc906f096 logical2 (
    .clk(1'b0),
    .ce(1'b0),
    .clr(1'b0),
    .d0(register5_q_net),
    .d1(delay4_q_net),
    .y(logical2_y_net)
  );
  axis_dma_throttle_w_cdc_xlregister #(
    .d_width(32),
    .init_value(32'b00000000000000000000000000000000)
  )
  register2 (
    .en(1'b1),
    .rst(1'b0),
    .d(frames_no_in_net),
    .clk(clk_net),
    .ce(ce_net),
    .q(register2_q_net)
  );
  axis_dma_throttle_w_cdc_xlregister #(
    .d_width(1),
    .init_value(1'b0)
  )
  register4 (
    .en(1'b1),
    .rst(1'b0),
    .d(trigger_in_net),
    .clk(clk_net),
    .ce(ce_net),
    .q(register4_q_net)
  );
  sysgen_logical_9fc906f096 logical3 (
    .clk(1'b0),
    .ce(1'b0),
    .clr(1'b0),
    .d0(delay2_q_net),
    .d1(register5_q_net),
    .y(logical3_y_net)
  );
  sysgen_inverter_9efd4a3e24 inverter (
    .clr(1'b0),
    .ip(register4_q_net),
    .clk(clk_net),
    .ce(ce_net),
    .op(inverter_op_net)
  );
  axis_dma_throttle_w_cdc_xldelay #(
    .latency(1),
    .reg_retiming(0),
    .reset(0),
    .width(1)
  )
  delay4 (
    .en(1'b1),
    .rst(1'b0),
    .d(logical_y_net),
    .clk(clk_net),
    .ce(ce_net),
    .q(delay4_q_net)
  );
  axis_dma_throttle_w_cdc_xlregister #(
    .d_width(1),
    .init_value(1'b0)
  )
  register5 (
    .d(logical4_y_net),
    .rst(mux2_y_net),
    .en(logical4_y_net),
    .clk(clk_net),
    .ce(ce_net),
    .q(register5_q_net)
  );
  sysgen_constant_fb7dcfa7fd constant (
    .clk(1'b0),
    .ce(1'b0),
    .clr(1'b0),
    .op(constant_op_net)
  );
  sysgen_logical_9fc906f096 logical4 (
    .clk(1'b0),
    .ce(1'b0),
    .clr(1'b0),
    .d0(register4_q_net),
    .d1(inverter_op_net),
    .y(logical4_y_net)
  );
endmodule
`timescale 1 ns / 10 ps
// Generated from Simulink block 
module axis_dma_throttle_w_cdc_default_clock_driver (
  input axis_dma_throttle_w_cdc_sysclk,
  input axis_dma_throttle_w_cdc_sysce,
  input axis_dma_throttle_w_cdc_sysclr,
  output axis_dma_throttle_w_cdc_clk1,
  output axis_dma_throttle_w_cdc_ce1
);
  xlclockdriver #(
    .period(1),
    .log_2_period(1)
  )
  clockdriver (
    .sysclk(axis_dma_throttle_w_cdc_sysclk),
    .sysce(axis_dma_throttle_w_cdc_sysce),
    .sysclr(axis_dma_throttle_w_cdc_sysclr),
    .clk(axis_dma_throttle_w_cdc_clk1),
    .ce(axis_dma_throttle_w_cdc_ce1)
  );
endmodule
`timescale 1 ns / 10 ps
// Generated from Simulink block 
(* core_generation_info = "axis_dma_throttle_w_cdc,sysgen_core_2020_2,{,compilation=IP Catalog,block_icon_display=Default,family=zynq,part=xc7z020,speed=-1,package=clg400,synthesis_language=verilog,hdl_library=xil_defaultlib,synthesis_strategy=Vivado Synthesis Defaults,implementation_strategy=Vivado Implementation Defaults,testbench=0,interface_doc=0,ce_clr=0,clock_period=8,system_simulink_period=8e-09,waveform_viewer=0,axilite_interface=1,ip_catalog_plugin=0,hwcosim_burst_mode=0,simulation_time=1.28e-06,constant=1,counter=3,delay=3,inv=1,logical=6,mux=2,register=7,relational=2,}" *)
module axis_dma_throttle_w_cdc (
  input [32-1:0] data_in_a,
  input [32-1:0] data_in_b,
  input [1-1:0] m_axis_dma_tready,
  input clk,
  input axis_dma_throttle_w_cdc_aresetn,
  input [4-1:0] axis_dma_throttle_w_cdc_cfg_in_s_axi_awaddr,
  input axis_dma_throttle_w_cdc_cfg_in_s_axi_awvalid,
  input [32-1:0] axis_dma_throttle_w_cdc_cfg_in_s_axi_wdata,
  input [4-1:0] axis_dma_throttle_w_cdc_cfg_in_s_axi_wstrb,
  input axis_dma_throttle_w_cdc_cfg_in_s_axi_wvalid,
  input axis_dma_throttle_w_cdc_cfg_in_s_axi_bready,
  input [4-1:0] axis_dma_throttle_w_cdc_cfg_in_s_axi_araddr,
  input axis_dma_throttle_w_cdc_cfg_in_s_axi_arvalid,
  input axis_dma_throttle_w_cdc_cfg_in_s_axi_rready,
  output [32-1:0] m_axis_dma_tdata,
  output [1-1:0] m_axis_dma_tvalid,
  output [1-1:0] m_axis_dma_tlast,
  output axis_dma_throttle_w_cdc_cfg_in_s_axi_awready,
  output axis_dma_throttle_w_cdc_cfg_in_s_axi_wready,
  output [2-1:0] axis_dma_throttle_w_cdc_cfg_in_s_axi_bresp,
  output axis_dma_throttle_w_cdc_cfg_in_s_axi_bvalid,
  output axis_dma_throttle_w_cdc_cfg_in_s_axi_arready,
  output [32-1:0] axis_dma_throttle_w_cdc_cfg_in_s_axi_rdata,
  output [2-1:0] axis_dma_throttle_w_cdc_cfg_in_s_axi_rresp,
  output axis_dma_throttle_w_cdc_cfg_in_s_axi_rvalid
);
  wire [32-1:0] frames_no_in;
  wire [1-1:0] trigger_in;
  wire clk_1_net;
  wire ce_1_net;
  wire [32-1:0] decim_in;
  wire clk_net;
  axis_dma_throttle_w_cdc_cfg_in_axi_lite_interface axis_dma_throttle_w_cdc_cfg_in_axi_lite_interface (
    .axis_dma_throttle_w_cdc_cfg_in_s_axi_awaddr(axis_dma_throttle_w_cdc_cfg_in_s_axi_awaddr),
    .axis_dma_throttle_w_cdc_cfg_in_s_axi_awvalid(axis_dma_throttle_w_cdc_cfg_in_s_axi_awvalid),
    .axis_dma_throttle_w_cdc_cfg_in_s_axi_wdata(axis_dma_throttle_w_cdc_cfg_in_s_axi_wdata),
    .axis_dma_throttle_w_cdc_cfg_in_s_axi_wstrb(axis_dma_throttle_w_cdc_cfg_in_s_axi_wstrb),
    .axis_dma_throttle_w_cdc_cfg_in_s_axi_wvalid(axis_dma_throttle_w_cdc_cfg_in_s_axi_wvalid),
    .axis_dma_throttle_w_cdc_cfg_in_s_axi_bready(axis_dma_throttle_w_cdc_cfg_in_s_axi_bready),
    .axis_dma_throttle_w_cdc_cfg_in_s_axi_araddr(axis_dma_throttle_w_cdc_cfg_in_s_axi_araddr),
    .axis_dma_throttle_w_cdc_cfg_in_s_axi_arvalid(axis_dma_throttle_w_cdc_cfg_in_s_axi_arvalid),
    .axis_dma_throttle_w_cdc_cfg_in_s_axi_rready(axis_dma_throttle_w_cdc_cfg_in_s_axi_rready),
    .axis_dma_throttle_w_cdc_cfg_in_aresetn(axis_dma_throttle_w_cdc_aresetn),
    .axis_dma_throttle_w_cdc_cfg_in_aclk(clk),
    .trigger_in(trigger_in),
    .frames_no_in(frames_no_in),
    .decim_in(decim_in),
    .axis_dma_throttle_w_cdc_cfg_in_s_axi_awready(axis_dma_throttle_w_cdc_cfg_in_s_axi_awready),
    .axis_dma_throttle_w_cdc_cfg_in_s_axi_wready(axis_dma_throttle_w_cdc_cfg_in_s_axi_wready),
    .axis_dma_throttle_w_cdc_cfg_in_s_axi_bresp(axis_dma_throttle_w_cdc_cfg_in_s_axi_bresp),
    .axis_dma_throttle_w_cdc_cfg_in_s_axi_bvalid(axis_dma_throttle_w_cdc_cfg_in_s_axi_bvalid),
    .axis_dma_throttle_w_cdc_cfg_in_s_axi_arready(axis_dma_throttle_w_cdc_cfg_in_s_axi_arready),
    .axis_dma_throttle_w_cdc_cfg_in_s_axi_rdata(axis_dma_throttle_w_cdc_cfg_in_s_axi_rdata),
    .axis_dma_throttle_w_cdc_cfg_in_s_axi_rresp(axis_dma_throttle_w_cdc_cfg_in_s_axi_rresp),
    .axis_dma_throttle_w_cdc_cfg_in_s_axi_rvalid(axis_dma_throttle_w_cdc_cfg_in_s_axi_rvalid),
    .clk(clk_net)
  );
  axis_dma_throttle_w_cdc_default_clock_driver axis_dma_throttle_w_cdc_default_clock_driver (
    .axis_dma_throttle_w_cdc_sysclk(clk_net),
    .axis_dma_throttle_w_cdc_sysce(1'b1),
    .axis_dma_throttle_w_cdc_sysclr(1'b0),
    .axis_dma_throttle_w_cdc_clk1(clk_1_net),
    .axis_dma_throttle_w_cdc_ce1(ce_1_net)
  );
  axis_dma_throttle_w_cdc_struct axis_dma_throttle_w_cdc_struct (
    .data_in_a(data_in_a),
    .data_in_b(data_in_b),
    .decim_in(decim_in),
    .m_axis_dma_tready(m_axis_dma_tready),
    .frames_no_in(frames_no_in),
    .trigger_in(trigger_in),
    .clk_1(clk_1_net),
    .ce_1(ce_1_net),
    .m_axis_dma_tdata(m_axis_dma_tdata),
    .m_axis_dma_tvalid(m_axis_dma_tvalid),
    .m_axis_dma_tlast(m_axis_dma_tlast)
  );
endmodule
