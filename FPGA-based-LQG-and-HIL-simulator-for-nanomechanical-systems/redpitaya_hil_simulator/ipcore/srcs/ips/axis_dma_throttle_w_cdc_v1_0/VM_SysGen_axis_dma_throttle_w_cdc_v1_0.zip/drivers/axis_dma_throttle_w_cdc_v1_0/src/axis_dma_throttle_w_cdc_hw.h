/**
*
* @file axis_dma_throttle_w_cdc_hw.h
*
* This header file contains identifiers and driver functions (or
* macros) that can be used to access the device.  The user should refer to the
* hardware device specification for more details of the device operation.
*/ 
#define AXIS_DMA_THROTTLE_W_CDC_TRIGGER_IN 0x0/**< trigger_in */
#define AXIS_DMA_THROTTLE_W_CDC_FRAMES_NO_IN 0x4/**< frames_no_in */
#define AXIS_DMA_THROTTLE_W_CDC_DECIM_IN 0x8/**< decim_in */
