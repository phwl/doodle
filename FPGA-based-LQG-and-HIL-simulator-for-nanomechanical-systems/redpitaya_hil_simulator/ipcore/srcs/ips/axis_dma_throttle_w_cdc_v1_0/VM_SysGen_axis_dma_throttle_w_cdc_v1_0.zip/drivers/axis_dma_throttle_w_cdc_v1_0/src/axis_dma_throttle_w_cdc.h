#ifndef AXIS_DMA_THROTTLE_W_CDC__H
#define AXIS_DMA_THROTTLE_W_CDC__H
#ifdef __cplusplus
extern "C" {
#endif
/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "axis_dma_throttle_w_cdc_hw.h"
/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 axis_dma_throttle_w_cdc_cfg_in_BaseAddress;
} axis_dma_throttle_w_cdc_Config;
#endif
/**
* The axis_dma_throttle_w_cdc driver instance data. The user is required to
* allocate a variable of this type for every axis_dma_throttle_w_cdc device in the system.
* A pointer to a variable of this type is then passed to the driver
* API functions.
*/
typedef struct {
    u32 axis_dma_throttle_w_cdc_cfg_in_BaseAddress;
    u32 IsReady;
} axis_dma_throttle_w_cdc;
/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define axis_dma_throttle_w_cdc_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define axis_dma_throttle_w_cdc_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define axis_dma_throttle_w_cdc_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define axis_dma_throttle_w_cdc_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif
/************************** Function Prototypes *****************************/
#ifndef __linux__
int axis_dma_throttle_w_cdc_Initialize(axis_dma_throttle_w_cdc *InstancePtr, u16 DeviceId);
axis_dma_throttle_w_cdc_Config* axis_dma_throttle_w_cdc_LookupConfig(u16 DeviceId);
int axis_dma_throttle_w_cdc_CfgInitialize(axis_dma_throttle_w_cdc *InstancePtr, axis_dma_throttle_w_cdc_Config *ConfigPtr);
#else
int axis_dma_throttle_w_cdc_Initialize(axis_dma_throttle_w_cdc *InstancePtr, const char* InstanceName);
int axis_dma_throttle_w_cdc_Release(axis_dma_throttle_w_cdc *InstancePtr);
#endif
/**
* Write to trigger_in gateway of axis_dma_throttle_w_cdc. Assignments are LSB-justified.
*
* @param	InstancePtr is the trigger_in instance to operate on.
* @param	Data is value to be written to gateway trigger_in.
*
* @return	None.
*
* @note    .
*
*/
void axis_dma_throttle_w_cdc_trigger_in_write(axis_dma_throttle_w_cdc *InstancePtr, u32 Data);
/**
* Read from trigger_in gateway of axis_dma_throttle_w_cdc. Assignments are LSB-justified.
*
* @param	InstancePtr is the trigger_in instance to operate on.
*
* @return	u32
*
* @note    .
*
*/
u32 axis_dma_throttle_w_cdc_trigger_in_read(axis_dma_throttle_w_cdc *InstancePtr);
/**
* Write to frames_no_in gateway of axis_dma_throttle_w_cdc. Assignments are LSB-justified.
*
* @param	InstancePtr is the frames_no_in instance to operate on.
* @param	Data is value to be written to gateway frames_no_in.
*
* @return	None.
*
* @note    .
*
*/
void axis_dma_throttle_w_cdc_frames_no_in_write(axis_dma_throttle_w_cdc *InstancePtr, u32 Data);
/**
* Read from frames_no_in gateway of axis_dma_throttle_w_cdc. Assignments are LSB-justified.
*
* @param	InstancePtr is the frames_no_in instance to operate on.
*
* @return	u32
*
* @note    .
*
*/
u32 axis_dma_throttle_w_cdc_frames_no_in_read(axis_dma_throttle_w_cdc *InstancePtr);
/**
* Write to decim_in gateway of axis_dma_throttle_w_cdc. Assignments are LSB-justified.
*
* @param	InstancePtr is the decim_in instance to operate on.
* @param	Data is value to be written to gateway decim_in.
*
* @return	None.
*
* @note    .
*
*/
void axis_dma_throttle_w_cdc_decim_in_write(axis_dma_throttle_w_cdc *InstancePtr, u32 Data);
/**
* Read from decim_in gateway of axis_dma_throttle_w_cdc. Assignments are LSB-justified.
*
* @param	InstancePtr is the decim_in instance to operate on.
*
* @return	u32
*
* @note    .
*
*/
u32 axis_dma_throttle_w_cdc_decim_in_read(axis_dma_throttle_w_cdc *InstancePtr);
#ifdef __cplusplus
}
#endif
#endif
