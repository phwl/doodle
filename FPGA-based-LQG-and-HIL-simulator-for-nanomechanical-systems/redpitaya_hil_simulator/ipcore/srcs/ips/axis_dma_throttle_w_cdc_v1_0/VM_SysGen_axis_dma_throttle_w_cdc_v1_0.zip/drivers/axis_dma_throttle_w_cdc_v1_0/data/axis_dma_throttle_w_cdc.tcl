proc generate {drv_handle} {
    xdefine_include_file $drv_handle "xparameters.h" "axis_dma_throttle_w_cdc" "NUM_INSTANCES" "DEVICE_ID" "C_AXIS_DMA_THROTTLE_W_CDC_CFG_IN_S_AXI_BASEADDR" "C_AXIS_DMA_THROTTLE_W_CDC_CFG_IN_S_AXI_HIGHADDR" 
    xdefine_config_file $drv_handle "axis_dma_throttle_w_cdc_g.c" "axis_dma_throttle_w_cdc" "DEVICE_ID" "C_AXIS_DMA_THROTTLE_W_CDC_CFG_IN_S_AXI_BASEADDR" 
    xdefine_canonical_xpars $drv_handle "xparameters.h" "axis_dma_throttle_w_cdc" "DEVICE_ID" "C_AXIS_DMA_THROTTLE_W_CDC_CFG_IN_S_AXI_BASEADDR" "C_AXIS_DMA_THROTTLE_W_CDC_CFG_IN_S_AXI_HIGHADDR" 

}