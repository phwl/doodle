/**
* @file axis_dma_throttle_w_cdc_sinit.c
*
* The implementation of the axis_dma_throttle_w_cdc driver's static initialzation
* functionality.
*
* @note
*
* None
*
*/
#ifndef __linux__
#include "xstatus.h"
#include "xparameters.h"
#include "axis_dma_throttle_w_cdc.h"
extern axis_dma_throttle_w_cdc_Config axis_dma_throttle_w_cdc_ConfigTable[];
/**
* Lookup the device configuration based on the unique device ID.  The table
* ConfigTable contains the configuration info for each device in the system.
*
* @param DeviceId is the device identifier to lookup.
*
* @return
*     - A pointer of data type axis_dma_throttle_w_cdc_Config which
*    points to the device configuration if DeviceID is found.
*    - NULL if DeviceID is not found.
*
* @note    None.
*
*/
axis_dma_throttle_w_cdc_Config *axis_dma_throttle_w_cdc_LookupConfig(u16 DeviceId) {
    axis_dma_throttle_w_cdc_Config *ConfigPtr = NULL;
    int Index;
    for (Index = 0; Index < XPAR_AXIS_DMA_THROTTLE_W_CDC_NUM_INSTANCES; Index++) {
        if (axis_dma_throttle_w_cdc_ConfigTable[Index].DeviceId == DeviceId) {
            ConfigPtr = &axis_dma_throttle_w_cdc_ConfigTable[Index];
            break;
        }
    }
    return ConfigPtr;
}
int axis_dma_throttle_w_cdc_Initialize(axis_dma_throttle_w_cdc *InstancePtr, u16 DeviceId) {
    axis_dma_throttle_w_cdc_Config *ConfigPtr;
    Xil_AssertNonvoid(InstancePtr != NULL);
    ConfigPtr = axis_dma_throttle_w_cdc_LookupConfig(DeviceId);
    if (ConfigPtr == NULL) {
        InstancePtr->IsReady = 0;
        return (XST_DEVICE_NOT_FOUND);
    }
    return axis_dma_throttle_w_cdc_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif
