#include "axis_dma_throttle_w_cdc.h"
#ifndef __linux__
int axis_dma_throttle_w_cdc_CfgInitialize(axis_dma_throttle_w_cdc *InstancePtr, axis_dma_throttle_w_cdc_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->axis_dma_throttle_w_cdc_cfg_in_BaseAddress = ConfigPtr->axis_dma_throttle_w_cdc_cfg_in_BaseAddress;

    InstancePtr->IsReady = 1;
    return XST_SUCCESS;
}
#endif
void axis_dma_throttle_w_cdc_trigger_in_write(axis_dma_throttle_w_cdc *InstancePtr, u32 Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    axis_dma_throttle_w_cdc_WriteReg(InstancePtr->axis_dma_throttle_w_cdc_cfg_in_BaseAddress, 0, Data);
}
u32 axis_dma_throttle_w_cdc_trigger_in_read(axis_dma_throttle_w_cdc *InstancePtr) {

    u32 Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = axis_dma_throttle_w_cdc_ReadReg(InstancePtr->axis_dma_throttle_w_cdc_cfg_in_BaseAddress, 0);
    return Data;
}
void axis_dma_throttle_w_cdc_frames_no_in_write(axis_dma_throttle_w_cdc *InstancePtr, u32 Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    axis_dma_throttle_w_cdc_WriteReg(InstancePtr->axis_dma_throttle_w_cdc_cfg_in_BaseAddress, 4, Data);
}
u32 axis_dma_throttle_w_cdc_frames_no_in_read(axis_dma_throttle_w_cdc *InstancePtr) {

    u32 Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = axis_dma_throttle_w_cdc_ReadReg(InstancePtr->axis_dma_throttle_w_cdc_cfg_in_BaseAddress, 4);
    return Data;
}
void axis_dma_throttle_w_cdc_decim_in_write(axis_dma_throttle_w_cdc *InstancePtr, u32 Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    axis_dma_throttle_w_cdc_WriteReg(InstancePtr->axis_dma_throttle_w_cdc_cfg_in_BaseAddress, 8, Data);
}
u32 axis_dma_throttle_w_cdc_decim_in_read(axis_dma_throttle_w_cdc *InstancePtr) {

    u32 Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = axis_dma_throttle_w_cdc_ReadReg(InstancePtr->axis_dma_throttle_w_cdc_cfg_in_BaseAddress, 8);
    return Data;
}
